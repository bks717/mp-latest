#!/usr/bin/env python3
"""
Creates the CSV files that the LaTeX graphs read from  data/ .
Only REAL model outputs go in. Nothing here invents numbers.

1) GRU ROC + reliability  (from your held-out TEST predictions)
   Prepare gru_test_predictions.csv with columns:  y_true,y_prob
   (0/1 label, predicted probability) for the geographically held-out test set.
       python export_figure_data.py gru gru_test_predictions.csv
   -> data/roc_gru.csv (fpr,tpr), data/reliability_gru.csv (mean_pred,frac_pos,count)
   It also prints AUC and Brier so you can confirm 0.8952 / 0.0469 before submitting.

2) U-Net training curves  -> data/unet_history.csv
   Copy the per-epoch validation numbers from colab_model_v4.ipynb into a CSV
   with header:  epoch,val_iou,val_dice   (one row per epoch, 1..50).

3) Multi-horizon forecast band -> data/forecast_band.csv
   From one live /unified-prediction response (tcn_attention_forecast +
   deep_ensemble_uncertainty) write a CSV with header:  h,mean,lo,hi
   for horizons 0,6,12,24,48,72  (lo/hi = 95% interval).
"""
import csv, os, sys
import numpy as np

def roc_points(y, p):
    order = np.argsort(-p)
    y = y[order]; p = p[order]
    tps = np.cumsum(y); fps = np.cumsum(1 - y)
    # keep one point per distinct threshold
    idx = np.r_[np.where(np.diff(p))[0], len(p) - 1]
    tpr = np.r_[0, tps[idx] / tps[-1]]
    fpr = np.r_[0, fps[idx] / fps[-1]]
    return fpr, tpr

def reliability(y, p, bins=10):
    edges = np.linspace(0, 1, bins + 1)
    ids = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    rows = []
    for b in range(bins):
        m = ids == b
        if m.sum() > 0:
            rows.append((p[m].mean(), y[m].mean(), int(m.sum())))
    return rows

def main():
    if len(sys.argv) != 3 or sys.argv[1] != "gru":
        print(__doc__); sys.exit(1)
    data = np.genfromtxt(sys.argv[2], delimiter=",", names=True)
    y = data["y_true"].astype(int); p = data["y_prob"].astype(float)
    os.makedirs("data", exist_ok=True)
    fpr, tpr = roc_points(y, p)
    _trap = getattr(np, "trapezoid", None) or np.trapz
    auc = float(_trap(tpr, fpr)); brier = float(np.mean((p - y) ** 2))
    with open("data/roc_gru.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["fpr", "tpr"]); w.writerows(zip(fpr, tpr))
    with open("data/reliability_gru.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["mean_pred", "frac_pos", "count"]); w.writerows(reliability(y, p))
    print(f"N={len(y)} positives={int(y.sum())}  AUC={auc:.4f}  Brier={brier:.4f}")
    print("Wrote data/roc_gru.csv and data/reliability_gru.csv")

if __name__ == "__main__":
    main()
